import { fileURLToPath } from 'url';
import path from 'path';
import { FlatCompat } from '@eslint/eslintrc';
import globals from 'globals';
import reactRefresh from 'eslint-plugin-react-refresh';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const compat = new FlatCompat({ baseDirectory: __dirname });

export default [
  {
    ignores: [
      'dist',
      'eslint.config.js',
      'postcss.config.js',
      'tailwind.config.js',
      'vite.config.js',
    ],
  },
  ...compat.extends('airbnb'),
  {
    files: ['**/*.{js,jsx}'],
    plugins: {
      'react-refresh': reactRefresh,
    },
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: globals.browser,
    },
    rules: {
      'linebreak-style': 'off',
      'react/react-in-jsx-scope': 'off',
      'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],
      'no-param-reassign': ['error', {
        props: true,
        ignorePropertyModificationsFor: [
          'state',
          'acc', 'accumulator', 'e', 'ctx',
          'req', 'request', 'res', 'response', 'staticContext',
        ],
      }],
      'import/extensions': ['error', 'ignorePackages', {
        js: 'never',
        jsx: 'never',
      }],
      'import/prefer-default-export': 'off',
    },
  },
];
