module.exports = {
  env: {
    browser: true,
    es2021: true,
  },
  extends: ['airbnb', 'airbnb/hooks'],
  parserOptions: {
    ecmaFeatures: { jsx: true },
    ecmaVersion: 'latest',
    sourceType: 'module',
  },
  rules: {
    // React 17+ new JSX transform — no need to import React in every file
    'react/react-in-jsx-scope': 'off',
    // Allow .jsx extension
    'react/jsx-filename-extension': ['warn', { extensions: ['.jsx'] }],
    // RTK uses Immer; state mutation in slice reducers is intentional
    'no-param-reassign': [
      'error',
      {
        props: true,
        ignorePropertyModificationsFor: ['state'],
      },
    ],
    // Vite resolves imports without extensions
    'import/extensions': 'off',
    // Allow devDependencies imports in config files
    'import/no-extraneous-dependencies': [
      'error',
      { devDependencies: ['vite.config.js', 'postcss.config.js', 'tailwind.config.js'] },
    ],
    // Windows uses CRLF; disable line ending enforcement
    'linebreak-style': 'off',
    // Allow circular imports for cross-slice Redux thunk listeners
    'import/no-cycle': 'off',
    // Single-export service files are fine — they may grow
    'import/prefer-default-export': 'off',
    // Forum API content may include HTML; disable dangerouslySetInnerHTML warning
    'react/no-danger': 'off',
  },
};
