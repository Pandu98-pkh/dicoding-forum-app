import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchThreads,
  setSelectedCategory,
  selectThreadsLoading,
  selectThreadsError,
  selectThreadsWithOwners,
  selectAllCategories,
  selectSelectedCategory,
} from '../store/slices/threadsSlice';
import { fetchUsers } from '../store/slices/usersSlice';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorMessage from '../components/common/ErrorMessage';
import CategoryFilter from '../components/common/CategoryFilter';
import ThreadList from '../components/thread/ThreadList';

function HomePage() {
  const dispatch = useDispatch();
  const isLoading = useSelector(selectThreadsLoading);
  const error = useSelector(selectThreadsError);
  const threads = useSelector(selectThreadsWithOwners);
  const categories = useSelector(selectAllCategories);
  const selectedCategory = useSelector(selectSelectedCategory);

  useEffect(() => {
    dispatch(fetchThreads());
    dispatch(fetchUsers());
  }, [dispatch]);

  const handleRetry = () => {
    dispatch(fetchThreads());
    dispatch(fetchUsers());
  };

  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} onRetry={handleRetry} />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Discussions</h1>
      </div>

      <CategoryFilter
        categories={categories}
        selected={selectedCategory}
        onSelect={(cat) => dispatch(setSelectedCategory(cat))}
      />

      <ThreadList threads={threads} />
    </div>
  );
}

export default HomePage;
